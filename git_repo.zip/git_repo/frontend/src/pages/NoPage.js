const NoPage = () => {
    return(
        <div class="container">
            <a class="loading" href="/chat">404 page not found. back to chat...</a>
        </div>
    )
}
export default NoPage;